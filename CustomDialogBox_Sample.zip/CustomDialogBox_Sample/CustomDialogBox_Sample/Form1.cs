﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using CustomMessageBox;

namespace CustomMessageBox_Sample
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            MsgBox db = new MsgBox("This is a simple message", "This is a test title");
            db.ShowDialog(this);

        }

        private void button2_Click(object sender, EventArgs e)
        {
            MsgBox db = new MsgBox("There are 2 buttons with custom names.\nUse \"SetButtons\" API.", "This is a test title", MessageBoxIcon.Information);
            db.SetButtons("First Button", "Second Button");
            db.ShowDialog(this);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            MsgBox db = new MsgBox("There is a checkbox.\nUse \"SetCheckbox\" API.", "This is a test title", MessageBoxIcon.Information);
            db.SetButtons("First Button", "Second Button");
            db.SetCheckbox("There is also a checkbox");
            db.ShowDialog(this);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            MsgBox db = new MsgBox("Set the size of the dialog box. Use \"SetMinSize\" API.", "This is a test title", MessageBoxIcon.Information);
            db.SetButtons("First Button", "Second Button");
            db.SetCheckbox("There is also a checkbox");
            db.SetMinSize(500, 500);
            db.ShowDialog(this);
        }

        private void button5_Click(object sender, EventArgs e)
        {
            MsgBox db = new MsgBox("There are 2 buttons with default second button.\nUse \"SetButtons\" API and set the \"results\" and \"def\" arguments.", "This is a test title", MessageBoxIcon.Information);
            db.SetButtons(new string[]{"First Button", "Second Button"}, new DialogResult[] {DialogResult.Yes, DialogResult.No}, 2);
            DialogResult r = db.ShowDialog(this);

        }
    }
}
